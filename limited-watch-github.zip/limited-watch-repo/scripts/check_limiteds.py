"""
Runs once per GitHub Actions invocation (see ../.github/workflows/check-limiteds.yml).

- Fetches the full Rolimons limiteds catalog (server-side here, so no browser
  CORS restriction applies).
- Compares each item's value to what we saw last run (data/history.json) to
  measure momentum.
- Scores every item (same heuristic as the original bot: trend, demand,
  momentum, RAP-vs-value gap, projected-item penalty).
- Posts a Discord webhook message for any item crossing SCORE_THRESHOLD that
  hasn't been alerted in the last ALERT_COOLDOWN_HOURS (data/alerted.json).
- Writes data/latest.json (top 50 scored items + run metadata) for the
  GitHub Pages dashboard to read.

No Discord bot, no token, no privileged intents — just a webhook URL pasted
into a Discord channel's Integrations settings.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import requests

ITEMDETAILS_URL = "https://www.rolimons.com/itemapi/itemdetails"
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; LimitedWatchBot/1.0; personal use)"}

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
HISTORY_PATH = DATA_DIR / "history.json"
ALERTED_PATH = DATA_DIR / "alerted.json"
LATEST_PATH = DATA_DIR / "latest.json"

DEMAND_LABELS = {-1: "None", 0: "Terrible", 1: "Low", 2: "Normal", 3: "High", 4: "Amazing"}
TREND_LABELS = {-1: "None", 0: "Lowering", 1: "Unstable", 2: "Stable", 3: "Raising", 4: "Fluctuating"}

SCORE_THRESHOLD = float(os.environ.get("SCORE_THRESHOLD", "6"))
ALERT_COOLDOWN_SECONDS = float(os.environ.get("ALERT_COOLDOWN_HOURS", "6")) * 3600
DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL", "").strip()
MOMENTUM_BULLISH_PCT = 5.0
UNDERPRICED_GAP_PCT = 8.0
# A previous snapshot older than this is considered stale and ignored for momentum
# (covers the gap if the workflow didn't run for a while).
MAX_MOMENTUM_LOOKBACK_SECONDS = 2 * 3600


def load_json(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return default


def save_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, separators=(",", ":")))


def fetch_items() -> dict:
    resp = requests.get(ITEMDETAILS_URL, headers=HEADERS, timeout=20)
    resp.raise_for_status()
    data = resp.json()
    if not data.get("success"):
        raise RuntimeError(f"Rolimons API returned success=false: {data}")

    items = {}
    for item_id, fields in data["items"].items():
        if len(fields) < 10:
            continue
        name, acronym, rap, value, default_value, demand, trend, projected, hyped, rare = fields
        items[item_id] = {
            "name": name,
            "acronym": acronym,
            "rap": rap,
            "value": value,
            "demand": demand,
            "trend": trend,
            "projected": projected == 1,
            "hyped": hyped == 1,
            "rare": rare == 1,
        }
    return items


def score_item(item_id: str, item: dict, history: dict, now: float) -> dict:
    score = 0.0
    reasons = []

    trend = item["trend"]
    if trend == 3:
        score += 3; reasons.append("Trend: Raising")
    elif trend == 4:
        score += 1; reasons.append("Trend: Fluctuating")
    elif trend == 0:
        score -= 3; reasons.append("Trend: Lowering")
    elif trend == 1:
        score -= 1; reasons.append("Trend: Unstable")

    demand = item["demand"]
    if demand == 4:
        score += 2; reasons.append("Demand: Amazing")
    elif demand == 3:
        score += 1; reasons.append("Demand: High")
    elif demand == 0:
        score -= 1; reasons.append("Demand: Terrible")

    momentum_pct = None
    prev = history.get(item_id)
    if prev and (now - prev["t"]) <= MAX_MOMENTUM_LOOKBACK_SECONDS and prev["value"] > 0:
        momentum_pct = ((item["value"] - prev["value"]) / prev["value"]) * 100
        if momentum_pct >= MOMENTUM_BULLISH_PCT:
            score += 3; reasons.append(f"Value up {momentum_pct:.1f}% since last check")
        elif momentum_pct <= -MOMENTUM_BULLISH_PCT:
            score -= 3; reasons.append(f"Value down {abs(momentum_pct):.1f}% since last check")

    if item["projected"]:
        score -= 4; reasons.append("Projected (manipulation risk)")

    if item["rap"] > 0 and item["value"] > 0:
        gap_pct = ((item["value"] - item["rap"]) / item["rap"]) * 100
        if gap_pct >= UNDERPRICED_GAP_PCT:
            score += 2; reasons.append(f"Value {gap_pct:.0f}% above RAP")

    return {
        "id": item_id,
        "name": item["name"],
        "value": item["value"],
        "rap": item["rap"],
        "demand_label": DEMAND_LABELS.get(demand, "Unknown"),
        "trend_label": TREND_LABELS.get(trend, "Unknown"),
        "projected": item["projected"],
        "hyped": item["hyped"],
        "rare": item["rare"],
        "score": round(score, 1),
        "momentum_pct": round(momentum_pct, 1) if momentum_pct is not None else None,
        "reasons": reasons,
        "url": f"https://www.rolimons.com/item/{item_id}",
    }


def send_discord_alerts(opportunities: list[dict]):
    if not DISCORD_WEBHOOK_URL:
        print("No DISCORD_WEBHOOK_URL set — skipping Discord alerts (data/latest.json still updated).")
        return

    def embed_for(o: dict) -> dict:
        color = 0x43C98A if o["score"] >= 0 else 0xF2545B
        fields = [
            {"name": "Score", "value": str(o["score"]), "inline": True},
            {"name": "Value", "value": f"{o['value']:,}", "inline": True},
            {"name": "RAP", "value": f"{o['rap']:,}", "inline": True},
            {"name": "Demand", "value": o["demand_label"], "inline": True},
            {"name": "Trend", "value": o["trend_label"], "inline": True},
        ]
        if o["momentum_pct"] is not None:
            fields.append({"name": "Momentum", "value": f"{o['momentum_pct']:+.1f}%", "inline": True})
        fields.append({"name": "Why", "value": "\n".join(f"• {r}" for r in o["reasons"]) or "—", "inline": False})
        return {
            "title": f"📈 {o['name']}",
            "url": o["url"],
            "color": color,
            "fields": fields,
            "footer": {"text": "Heuristic signal from public Rolimons data — not financial advice."},
        }

    # Discord allows up to 10 embeds per message; chunk if needed.
    for i in range(0, len(opportunities), 10):
        chunk = opportunities[i:i + 10]
        payload = {"embeds": [embed_for(o) for o in chunk]}
        resp = requests.post(DISCORD_WEBHOOK_URL, json=payload, timeout=15)
        if resp.status_code >= 300:
            print(f"Discord webhook failed ({resp.status_code}): {resp.text[:300]}")


def main():
    now = time.time()
    history = load_json(HISTORY_PATH, {})
    alerted = load_json(ALERTED_PATH, {})

    items = fetch_items()

    scored = [score_item(item_id, item, history, now) for item_id, item in items.items()]
    scored.sort(key=lambda o: o["score"], reverse=True)

    # Update history with this run's values (for next run's momentum calc).
    new_history = {item_id: {"value": item["value"], "t": now} for item_id, item in items.items()}
    save_json(HISTORY_PATH, new_history)

    # Find new opportunities (above threshold, not alerted within cooldown).
    new_opportunities = []
    for o in scored:
        if o["score"] < SCORE_THRESHOLD:
            continue
        last_alert = alerted.get(o["id"], 0)
        if now - last_alert < ALERT_COOLDOWN_SECONDS:
            continue
        alerted[o["id"]] = now
        new_opportunities.append(o)

    # Prune alerted.json entries for items no longer tracked, to keep it bounded.
    alerted = {iid: t for iid, t in alerted.items() if iid in items}
    save_json(ALERTED_PATH, alerted)

    if new_opportunities:
        print(f"{len(new_opportunities)} new opportunit{'y' if len(new_opportunities)==1 else 'ies'}: "
              + ", ".join(o["name"] for o in new_opportunities))
        send_discord_alerts(new_opportunities)
    else:
        print("No new opportunities this run.")

    save_json(LATEST_PATH, {
        "last_run": now,
        "item_count": len(items),
        "score_threshold": SCORE_THRESHOLD,
        "top": scored[:50],
    })


if __name__ == "__main__":
    main()
