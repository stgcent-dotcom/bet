# Limited Watch — GitHub Edition

Runs server-side on GitHub's free Actions scheduler, so there's no CORS
problem and nothing has to stay open on your computer. Posts alerts to
Discord via a webhook (no bot account, no token, no permissions to set up).

## What you get

- `check-limiteds.yml` — runs every 15 minutes, fetches Rolimons data,
  scores every limited, and posts a Discord message for new opportunities.
- `index.html` — a dashboard (hosted free via GitHub Pages) showing the
  latest results, auto-refreshing every 2 minutes.
- `data/*.json` — the Action's working data, updated every run.

## Setup (all done in the browser, no git required)

### 1. Create the repo
- Go to https://github.com/new
- Name it anything (e.g. `limited-watch`), set it to **Public** (required
  for free GitHub Pages), click **Create repository**.

### 2. Upload these files
- On your new repo's page, click **Add file → Upload files**.
- Drag in the whole folder I gave you (or all the files/folders, keeping
  the same structure: `.github/workflows/check-limiteds.yml`,
  `scripts/check_limiteds.py`, `data/history.json`, `data/alerted.json`,
  `data/latest.json`, `index.html`).
- Scroll down, click **Commit changes**.

### 3. Create your Discord webhook
- In Discord, go to the channel you want alerts in → ⚙️ **Edit Channel**
  → **Integrations** → **Webhooks** → **New Webhook**.
- Give it a name, click **Copy Webhook URL**. Keep this private — anyone
  with it can post to that channel.

### 4. Add the webhook as a secret
- In your repo: **Settings → Secrets and variables → Actions → New
  repository secret**.
- Name: `DISCORD_WEBHOOK_URL`
- Value: paste the URL you copied. Save.

### 5. Let the Action write back to the repo
- **Settings → Actions → General**, scroll to **Workflow permissions**.
- Select **Read and write permissions**. Save.
  (Without this, the Action can't save its history/results.)

### 6. Turn on GitHub Pages (for the dashboard)
- **Settings → Pages**.
- Under **Build and deployment → Source**, choose **Deploy from a
  branch**. Branch: `main`, folder: `/ (root)`. Save.
- After a minute or two, your dashboard will be live at
  `https://<your-username>.github.io/<repo-name>/`.

### 7. Run it
- Go to the **Actions** tab → click **Check Roblox limiteds** on the left
  → **Run workflow** → **Run workflow** (green button). This does a
  manual first run so you don't have to wait 15 minutes.
- Check your Discord channel and the dashboard URL once it finishes
  (~30–60 seconds).

After that, it just runs itself every 15 minutes.

## Tuning

Edit these two lines in `.github/workflows/check-limiteds.yml`:
```yaml
SCORE_THRESHOLD: "6"          # lower = more alerts, higher = fewer/stronger
ALERT_COOLDOWN_HOURS: "6"     # minimum gap before re-alerting the same item
```
And the schedule itself (`cron: "*/15 * * * *"`) if you want it less
frequent — GitHub charges Actions minutes past a generous free monthly
quota, so don't go faster than 15 min without checking your usage.

## Honest limits

- **15-minute granularity is the realistic floor** for a free scheduled
  job like this — GitHub doesn't guarantee schedules run faster than that,
  and can run a few minutes late when their infra is busy.
- This is read-only analysis. It never logs into Roblox, touches your
  inventory, or places trades — you stay in control of every trade.
- Limited prices are speculative. Treat alerts as "worth a look," not
  guaranteed profit.

## Files

- `.github/workflows/check-limiteds.yml` — the schedule + job definition
- `scripts/check_limiteds.py` — fetch, score, alert, save
- `data/history.json` — last-seen value per item (for momentum)
- `data/alerted.json` — cooldown tracking so items aren't re-alerted constantly
- `data/latest.json` — what the dashboard reads
- `index.html` — the dashboard (served by GitHub Pages)
